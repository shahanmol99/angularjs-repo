angular.module('spa', [])
    .controller('homeController',[function() {

    }])

    .controller('aboutController',[function() {
        
    }])

    .controller('careerController',[function() {
        
    }])

